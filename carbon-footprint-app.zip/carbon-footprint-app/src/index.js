import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import CarbonApp from './CarbonApp';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <CarbonApp />
  </React.StrictMode>
);