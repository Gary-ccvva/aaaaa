import { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'YOUR_AUTH_DOMAIN',
  projectId: 'YOUR_PROJECT_ID',
  storageBucket: 'YOUR_STORAGE_BUCKET',
  messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
  appId: 'YOUR_APP_ID',
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();

const emissionData = [
  { date: '1/1', value: 4.2 },
  { date: '1/2', value: 4.5 },
  { date: '1/3', value: 3.8 },
  { date: '1/4', value: 4.1 },
  { date: '1/5', value: 4.6 },
];

export default function CarbonApp() {
  const [selectedTab, setSelectedTab] = useState('home');
  const [user, setUser] = useState(null);

  const [commute, setCommute] = useState('');
  const [publicTrans, setPublicTrans] = useState('');
  const [vehicle, setVehicle] = useState('');
  const [diet, setDiet] = useState('');
  const [utility, setUtility] = useState('');

  useEffect(() => {
    onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
      } else {
        setUser(null);
      }
    });
  }, []);

  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      const userRef = doc(db, 'users', result.user.uid);
      const docSnap = await getDoc(userRef);
      if (!docSnap.exists()) {
        await setDoc(userRef, {
          displayName: result.user.displayName,
          email: result.user.email,
          emissions: [],
        });
      }
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const saveUserData = async () => {
    if (!user) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        commute,
        publicTrans,
        vehicle,
        diet,
        utility,
      });
      alert('✅ 資料已儲存！');
    } catch (err) {
      console.error('儲存失敗:', err);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Top Button Bar */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">碳足跡追蹤器</h1>
        <div className="flex gap-2">
          {user ? (
            <span className="text-sm">歡迎, {user.displayName}</span>
          ) : (
            <Button onClick={handleLogin}>使用 Google 登入</Button>
          )}
          <Button onClick={() => setSelectedTab('account')}>👤 個人帳戶</Button>
          <Button onClick={() => setSelectedTab('friends')}>👥 好友</Button>
          <Button onClick={() => setSelectedTab('donate')}>💚 支持環保</Button>
        </div>
      </div>

      {/* Tabs Content */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        {/* 主頁 */}
        <TabsContent value="home">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <h2 className="text-xl font-semibold">碳排放統計</h2>
              <p>📅 每日 / 每月 / 每年 排放量</p>
              <p>📈 累積排放量</p>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={emissionData}>
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" stroke="#8884d8" />
                </LineChart>
              </ResponsiveContainer>
              <p>🧑‍🤝‍🧑 好友 / 全球 排名</p>
              <p>📋 今日行程提醒</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 個人帳戶 */}
        <TabsContent value="account">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <h2 className="text-xl font-semibold">個人資料設定</h2>
              <h3 className="font-medium">🚆 交通工具</h3>
              <Input placeholder="通勤距離（公里）" value={commute} onChange={(e) => setCommute(e.target.value)} />
              <Textarea placeholder="捷運、公車…" value={publicTrans} onChange={(e) => setPublicTrans(e.target.value)} />
              <Textarea placeholder="汽/機車：排氣量、油耗…" value={vehicle} onChange={(e) => setVehicle(e.target.value)} />
              <h3 className="font-medium">🍽 飲食習慣</h3>
              <Textarea placeholder="葷 / 素 / 彈性" value={diet} onChange={(e) => setDiet(e.target.value)} />
              <h3 className="font-medium">💡 每月用電/用水</h3>
              <Input placeholder="水電度數" value={utility} onChange={(e) => setUtility(e.target.value)} />
              <Button className="mt-4" onClick={saveUserData}>💾 儲存資料</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 好友功能 */}
        <TabsContent value="friends">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <h2 className="text-xl font-semibold">好友互動</h2>
              <Button>➕ 新增好友</Button>
              <p>📊 好友碳排放量比較</p>
              <p>💬 聊天功能</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 支持環保 */}
        <TabsContent value="donate">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <h2 className="text-xl font-semibold">支持環保團體</h2>
              <Button>捐款</Button>
              <p>推薦團體清單 / 自由輸入</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
